/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Exception.java to edit this template
 */
package isi.deso.tpdeso2024.excepciones;

/**
 *
 * @author augus
 */
public class VendedorNoEncontradoException extends Exception{

    public VendedorNoEncontradoException(String mensaje){
    super(mensaje);
    
    }
}
